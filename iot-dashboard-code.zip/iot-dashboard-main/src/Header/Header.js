import React from 'react'
import './Header.css'


function Header() {
    return (
        <div className="header">
            
            <div className="home">
            

            <h1 className="headere">DASHBOARD</h1>

            </div>
            
        </div>
    )
}

export default Header